import React from "react";
import { useSelector } from "react-redux";
import { NavLink } from "react-router-dom";
import logo from '../images/logo.jpg'
import {FaShoppingCart,FaHeart} from "react-icons/fa"

const Navbar = () => {
  const { cart } = useSelector((state) => state);
  return (
    <div className="header">
      <div className="logo">
      <NavLink to="/">
        <img className="logo-img" src={logo}/>
      </NavLink>
      </div>
      <div className="head">
      <NavLink to="/">
          <p className="heading">Home</p>
        </NavLink>
        <NavLink to="/wishlist">
          <p className="heading"><FaHeart className="icons"/></p>
        </NavLink>
        <NavLink to="/cart">
          <p className="heading"><FaShoppingCart className="icons"/><sup>{cart.length>0?(<span className="superscript">{cart.length}</span>):""}</sup></p>
        </NavLink>
      </div>
    </div>
  );
};

export default Navbar;
