import React from 'react'

const Spinner = () => {
  return (
   <div className='image-box'>
     <div className="custom-loader"></div>
   </div>
  )
}

export default Spinner