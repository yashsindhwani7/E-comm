import { createSlice } from "@reduxjs/toolkit";

export const WishSlice = createSlice({
  name: "wish",
  initialState: [],
  reducers: {
    wishAdd: (state, action) => {
      state.push(action.payload);
    },
    wishRemove: (state, action) => {
      return state.filter((item) => item.id !== action.payload);
    },
  },
});

console.log(WishSlice.actions)

export default WishSlice.reducer;
export const { wishAdd, wishRemove } = WishSlice.actions;
