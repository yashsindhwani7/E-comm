import { createSlice } from "@reduxjs/toolkit";

export const CartSlice = createSlice({
  name: "cart",
  initialState: [],
  reducers: {
    cartAdd(state, action){
      state.push(action.payload);
    },
    cartRemove(state, action){
      return state.filter((item) => item.id !== action.payload);
    },
  },
});

export default CartSlice.reducer;
export const { cartAdd, cartRemove } = CartSlice.actions;
