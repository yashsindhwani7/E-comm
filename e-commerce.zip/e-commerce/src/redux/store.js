import { combineReducers, configureStore } from "@reduxjs/toolkit";
import CartSlice from "./slices/CartSlice";
import WishSlice from "./slices/WishSlice";

const rootReducer = combineReducers({
  cart: CartSlice,
  wish: WishSlice,
});

export const store = configureStore({
  reducer: rootReducer,
});
