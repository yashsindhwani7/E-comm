import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import CartItem from "../components/CartItem";

const Cart = () => {
  const { cart } = useSelector((state) => state);
  const [totalAmount, setTotalAmount] = useState(0);

  useEffect(() => {
    setTotalAmount(cart.reduce((acc, curr) => acc + curr.price, 0));
  }, [cart]);

  return (
    <div>
      {cart.length > 0 ? (
        <div className="cart">
          <div>
            {cart.map((item, index) => {
              return (
                <div>
                  <CartItem key={cart.id} item={item} index={index} />
                  <hr className="hr-vertical" />
                </div>
              );
            })}
          </div>
          <hr className="hr-horizontal" />
          <div className="cart-right">
            <div>
              <p className="your-cart">Your Cart</p>
              <p className="summary"> Summary</p>
              <p className="total-items">
                Total Items:<span className="no-items">{cart.length}</span>
              </p>
              <p className="total-amount">
                Total Amount:<span className="no-amount">${totalAmount}</span>
              </p>
            </div>
            <div className="amount-div">
              <p className="total-amount">
                Pay:<span className="no-amount">${totalAmount}</span>
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div className="empty">
          <p>Your Cart is Empty!</p>
          <button className="shop-btn">
            <Link to="/" className="shop">Shop Now</Link>
          </button>
        </div>
      )}
    </div>
  );
};

export default Cart;
