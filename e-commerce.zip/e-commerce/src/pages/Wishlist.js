import React from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import WishItem from "../components/WishItem";

const Wishlist = () => {
  const { wish } = useSelector((state) => state);

  return (
    <div>
      {wish.length > 0 ? (
        <div className="posts">
          {wish.map((item, index) => {
            return (
              <div>
                <WishItem key={wish.id} item={item} index={index} />
              </div>
            );
          })}
        </div>
      ) : (
        <div className="empty">
          <p>Your Wishlist is Empty!</p>
          <button className="shop-btn">
            <Link to="/" className="shop">Shop Now</Link>
          </button>
        </div>
      )}
    </div>
  );
};

export default Wishlist;
